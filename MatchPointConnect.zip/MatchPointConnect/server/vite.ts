// ✅ vite.ts 단순 로거 대체 버전
console.log("Vite stub loaded for build environment.");

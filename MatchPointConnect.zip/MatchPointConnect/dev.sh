#!/bin/bash
npx tsx server/dev.ts

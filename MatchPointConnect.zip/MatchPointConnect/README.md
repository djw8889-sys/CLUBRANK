# 🎾 ClubRank

**ClubRank**은 테니스 클럽을 위한 종합 관리 플랫폼입니다. 클럽 간 교류전, 멤버 관리, ELO 기반 랭킹 시스템, 자동 대진표 생성 등의 기능을 제공합니다.

## ✨ 주요 기능

### 🏆 클럽 관리
- 클럽 아이덴티티 커스터마이징 (엠블럼, 색상, 소개)
- 멤버 관리 및 역할 설정
- 클럽 모임 일정 관리

### 📊 랭킹 시스템
- **클럽 ELO 레이팅**: 교류전 결과 기반 클럽 순위
- **개인 랭킹**: 멤버 개인별 실력 추적
- **5가지 게임 포맷 분석**: 남단, 여단, 복식, 혼복, 단식

### 🏅 교류전 관리
- 자동 대진표 생성
- 실시간 경기 결과 업데이트
- 게임 포맷별 상세 통계

### 💬 커뮤니티
- 클럽 공지사항 및 게시판
- 실시간 채팅 시스템
- 멤버 간 소통 강화

## 🎨 디자인

**Smash 스타일 UI**
- 라임그린 (#C7F244) + 다크블루 (#1A2332) 테마
- 모바일 최적화 디자인
- 그라데이션 효과 및 애니메이션

## 🛠️ 기술 스택

### Frontend
- **Framework**: React 18 + TypeScript
- **UI**: shadcn/ui + Tailwind CSS
- **State Management**: TanStack React Query
- **Routing**: Wouter

### Backend
- **Runtime**: Node.js + Express.js
- **Database**: Firebase Firestore
- **Auth**: Firebase Authentication (Google OAuth)
- **Build**: Vite + esbuild

### DevOps
- **Deployment**: Railway
- **Version Control**: Git + GitHub
- **CI/CD**: Railway 자동 배포

## 🚀 빠른 시작

### 로컬 개발

1. **의존성 설치**
```bash
npm install
```

2. **환경변수 설정**
`.env.example`을 참고하여 `.env` 파일 생성:
```bash
cp .env.example .env
# .env 파일을 열어 Firebase 키 입력
```

3. **개발 서버 실행**
```bash
npm run dev
```

서버가 `http://localhost:5000`에서 실행됩니다.

### 프로덕션 빌드

```bash
npm run build
npm start
```

## 📦 배포

### Railway 배포

자세한 배포 가이드는 다음 문서를 참고하세요:

1. **GitHub 연결**: [`GITHUB_SETUP.md`](./GITHUB_SETUP.md)
2. **Railway 배포**: [`DEPLOYMENT.md`](./DEPLOYMENT.md)

### 간단 요약:
1. GitHub 저장소 생성 및 코드 푸시
2. Railway에서 GitHub 저장소 연결
3. 환경변수 설정
4. 자동 배포 시작

⚡ `main` 브랜치에 푸시할 때마다 자동으로 재배포됩니다!

## 🔐 환경변수

필요한 환경변수 목록은 `.env.example` 파일을 참고하세요.

### Firebase 설정:
- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_PROJECT_ID`
- `VITE_FIREBASE_APP_ID`
- `FIREBASE_SERVICE_ACCOUNT` (Backend)

## 📁 프로젝트 구조

```
club-rank/
├── client/                 # Frontend 코드
│   ├── src/
│   │   ├── components/    # React 컴포넌트
│   │   ├── hooks/         # Custom hooks
│   │   ├── pages/         # 페이지 컴포넌트
│   │   └── lib/           # 유틸리티 함수
│   └── index.html
├── server/                 # Backend 코드
│   ├── routes/            # API 라우트
│   ├── index.ts           # 서버 진입점
│   └── firebase-admin.ts  # Firebase Admin 설정
├── shared/                 # 공유 타입 및 스키마
├── .env.example           # 환경변수 템플릿
├── railway.json           # Railway 배포 설정
├── DEPLOYMENT.md          # 배포 가이드
└── package.json
```

## 🧪 개발 스크립트

```bash
# 개발 서버 실행
npm run dev

# 프로덕션 빌드
npm run build

# 프로덕션 서버 실행
npm start

# TypeScript 타입 체크
npm run check
```

## 🌟 MVP 전환 단계

ClubRank는 5단계의 MVP 전환을 거쳤습니다:

1. **Phase 1**: "Club Rank" 리브랜딩 및 네비게이션 재구성
2. **Phase 2**: 클럽 관리 데이터베이스 확장 (5가지 게임 포맷)
3. **Phase 3**: 핵심 클럽 기능 (대진표 생성, 분석 대시보드)
4. **Phase 4**: 개인 전적 강화 및 위치 기반 매칭
5. **Phase 5**: 완전한 클럽 중심 플랫폼 전환
   - 개인 매칭 기능 완전 제거
   - "ClubRank" 브랜딩 적용
   - Smash 스타일 UI (#C7F244 + #1A2332)
   - 4탭 네비게이션 (내 클럽/랭킹/커뮤니티/내 정보)

## 📝 라이선스

MIT License

## 👥 기여

이 프로젝트에 기여하고 싶으신가요?
1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📧 문의

프로젝트 관련 문의사항이 있으시면 GitHub Issues를 통해 연락주세요.

---

**ClubRank** - 테니스 클럽 관리의 새로운 기준 🎾✨
